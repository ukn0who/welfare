/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QTextEdit *te_show_data;
    QPushButton *btn_prev;
    QPushButton *btn_next;
    QPushButton *btn_jump;
    QTextEdit *et_page_num;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QStringLiteral("Dialog"));
        Dialog->resize(839, 755);
        QFont font;
        font.setFamily(QStringLiteral("SimSun"));
        Dialog->setFont(font);
        te_show_data = new QTextEdit(Dialog);
        te_show_data->setObjectName(QStringLiteral("te_show_data"));
        te_show_data->setGeometry(QRect(0, 0, 861, 671));
        btn_prev = new QPushButton(Dialog);
        btn_prev->setObjectName(QStringLiteral("btn_prev"));
        btn_prev->setGeometry(QRect(150, 690, 89, 25));
        QFont font1;
        font1.setFamily(QStringLiteral("Noto Sans CJK SC"));
        btn_prev->setFont(font1);
        btn_next = new QPushButton(Dialog);
        btn_next->setObjectName(QStringLiteral("btn_next"));
        btn_next->setGeometry(QRect(280, 690, 89, 25));
        btn_next->setFont(font1);
        btn_jump = new QPushButton(Dialog);
        btn_jump->setObjectName(QStringLiteral("btn_jump"));
        btn_jump->setGeometry(QRect(570, 690, 89, 25));
        btn_jump->setFont(font1);
        et_page_num = new QTextEdit(Dialog);
        et_page_num->setObjectName(QStringLiteral("et_page_num"));
        et_page_num->setGeometry(QRect(410, 690, 121, 31));

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", Q_NULLPTR));
        btn_prev->setText(QApplication::translate("Dialog", "Prev", Q_NULLPTR));
        btn_next->setText(QApplication::translate("Dialog", "Next", Q_NULLPTR));
        btn_jump->setText(QApplication::translate("Dialog", "Jump", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
