/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QListWidget *lw_process;
    QPushButton *btn_kill;
    QPushButton *btn_refresh;
    QWidget *tab_3;
    QLabel *label_11;
    QProgressBar *progressBar_CPU;
    QLabel *label_12;
    QProgressBar *progressBar_RAM;
    QLabel *label_14;
    QLabel *ram_used;
    QLabel *label_18;
    QLabel *ram_left;
    QLabel *label_20;
    QLabel *ram_total;
    QWidget *tab_2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *cpu_name;
    QLabel *cpu_type;
    QLabel *cpu_feq;
    QLabel *cache_size;
    QLabel *label_10;
    QLabel *system_type;
    QLabel *label_13;
    QLabel *gcc_version;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *system_version;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *total;
    QLabel *running;
    QLabel *sleep;
    QLabel *zombie;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(901, 552);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(60, 20, 641, 411));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        lw_process = new QListWidget(tab);
        lw_process->setObjectName(QStringLiteral("lw_process"));
        lw_process->setGeometry(QRect(0, 0, 641, 341));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(5);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lw_process->sizePolicy().hasHeightForWidth());
        lw_process->setSizePolicy(sizePolicy);
        lw_process->setModelColumn(0);
        btn_kill = new QPushButton(tab);
        btn_kill->setObjectName(QStringLiteral("btn_kill"));
        btn_kill->setGeometry(QRect(390, 350, 89, 25));
        btn_refresh = new QPushButton(tab);
        btn_refresh->setObjectName(QStringLiteral("btn_refresh"));
        btn_refresh->setGeometry(QRect(520, 350, 89, 25));
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        label_11 = new QLabel(tab_3);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(30, 40, 67, 17));
        progressBar_CPU = new QProgressBar(tab_3);
        progressBar_CPU->setObjectName(QStringLiteral("progressBar_CPU"));
        progressBar_CPU->setGeometry(QRect(77, 80, 481, 31));
        progressBar_CPU->setValue(24);
        label_12 = new QLabel(tab_3);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(30, 190, 67, 17));
        progressBar_RAM = new QProgressBar(tab_3);
        progressBar_RAM->setObjectName(QStringLiteral("progressBar_RAM"));
        progressBar_RAM->setGeometry(QRect(80, 250, 481, 31));
        progressBar_RAM->setValue(24);
        label_14 = new QLabel(tab_3);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(80, 310, 67, 17));
        ram_used = new QLabel(tab_3);
        ram_used->setObjectName(QStringLiteral("ram_used"));
        ram_used->setGeometry(QRect(130, 310, 131, 17));
        label_18 = new QLabel(tab_3);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(270, 310, 67, 17));
        ram_left = new QLabel(tab_3);
        ram_left->setObjectName(QStringLiteral("ram_left"));
        ram_left->setGeometry(QRect(310, 310, 111, 17));
        label_20 = new QLabel(tab_3);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(420, 310, 67, 17));
        ram_total = new QLabel(tab_3);
        ram_total->setObjectName(QStringLiteral("ram_total"));
        ram_total->setGeometry(QRect(490, 310, 101, 17));
        tabWidget->addTab(tab_3, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        label = new QLabel(tab_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 10, 121, 31));
        label_2 = new QLabel(tab_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(40, 40, 121, 31));
        label_3 = new QLabel(tab_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(40, 80, 121, 31));
        label_4 = new QLabel(tab_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 120, 121, 31));
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(40, 160, 121, 31));
        cpu_name = new QLabel(tab_2);
        cpu_name->setObjectName(QStringLiteral("cpu_name"));
        cpu_name->setGeometry(QRect(280, 40, 311, 31));
        cpu_type = new QLabel(tab_2);
        cpu_type->setObjectName(QStringLiteral("cpu_type"));
        cpu_type->setGeometry(QRect(280, 70, 311, 31));
        cpu_feq = new QLabel(tab_2);
        cpu_feq->setObjectName(QStringLiteral("cpu_feq"));
        cpu_feq->setGeometry(QRect(280, 110, 311, 31));
        cache_size = new QLabel(tab_2);
        cache_size->setObjectName(QStringLiteral("cache_size"));
        cache_size->setGeometry(QRect(280, 150, 311, 31));
        label_10 = new QLabel(tab_2);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(10, 200, 121, 31));
        system_type = new QLabel(tab_2);
        system_type->setObjectName(QStringLiteral("system_type"));
        system_type->setGeometry(QRect(280, 230, 311, 31));
        label_13 = new QLabel(tab_2);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(40, 310, 121, 31));
        gcc_version = new QLabel(tab_2);
        gcc_version->setObjectName(QStringLiteral("gcc_version"));
        gcc_version->setGeometry(QRect(280, 300, 311, 31));
        label_15 = new QLabel(tab_2);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(40, 270, 121, 31));
        label_16 = new QLabel(tab_2);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(40, 230, 121, 31));
        system_version = new QLabel(tab_2);
        system_version->setObjectName(QStringLiteral("system_version"));
        system_version->setGeometry(QRect(280, 260, 311, 31));
        tabWidget->addTab(tab_2, QString());
        system_type->raise();
        cpu_name->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        label_5->raise();
        cpu_type->raise();
        cpu_feq->raise();
        cache_size->raise();
        label_10->raise();
        label_13->raise();
        gcc_version->raise();
        label_15->raise();
        label_16->raise();
        system_version->raise();
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(720, 90, 67, 17));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(720, 180, 67, 17));
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(720, 260, 67, 17));
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(720, 340, 67, 17));
        total = new QLabel(centralWidget);
        total->setObjectName(QStringLiteral("total"));
        total->setGeometry(QRect(780, 90, 67, 17));
        running = new QLabel(centralWidget);
        running->setObjectName(QStringLiteral("running"));
        running->setGeometry(QRect(790, 180, 67, 17));
        sleep = new QLabel(centralWidget);
        sleep->setObjectName(QStringLiteral("sleep"));
        sleep->setGeometry(QRect(790, 260, 67, 17));
        zombie = new QLabel(centralWidget);
        zombie->setObjectName(QStringLiteral("zombie"));
        zombie->setGeometry(QRect(790, 340, 67, 17));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 901, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        btn_kill->setText(QApplication::translate("MainWindow", "Kill", Q_NULLPTR));
        btn_refresh->setText(QApplication::translate("MainWindow", "Refresh", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Process", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "CPU:", Q_NULLPTR));
        label_12->setText(QApplication::translate("MainWindow", "Memory:", Q_NULLPTR));
        label_14->setText(QApplication::translate("MainWindow", "Used:", Q_NULLPTR));
        ram_used->setText(QApplication::translate("MainWindow", "000", Q_NULLPTR));
        label_18->setText(QApplication::translate("MainWindow", "Left:", Q_NULLPTR));
        ram_left->setText(QApplication::translate("MainWindow", "000", Q_NULLPTR));
        label_20->setText(QApplication::translate("MainWindow", "Total:", Q_NULLPTR));
        ram_total->setText(QApplication::translate("MainWindow", "000", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "Memory", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Process", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "CPU Name:", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "CPU Type:", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "CPU Feq:", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Cache Size:", Q_NULLPTR));
        cpu_name->setText(QApplication::translate("MainWindow", "CPU Name:", Q_NULLPTR));
        cpu_type->setText(QApplication::translate("MainWindow", "CPU Name:", Q_NULLPTR));
        cpu_feq->setText(QApplication::translate("MainWindow", "CPU Name:", Q_NULLPTR));
        cache_size->setText(QApplication::translate("MainWindow", "CPU Name:", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "System", Q_NULLPTR));
        system_type->setText(QApplication::translate("MainWindow", "CPU Name:", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "GCC Version:", Q_NULLPTR));
        gcc_version->setText(QApplication::translate("MainWindow", "CPU Name:", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "System Version:", Q_NULLPTR));
        label_16->setText(QApplication::translate("MainWindow", "System Type:", Q_NULLPTR));
        system_version->setText(QApplication::translate("MainWindow", "CPU Name:", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "System", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "Total:", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Running:", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Sleep:", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "Zombie:", Q_NULLPTR));
        total->setText(QApplication::translate("MainWindow", "Total:", Q_NULLPTR));
        running->setText(QApplication::translate("MainWindow", "Total:", Q_NULLPTR));
        sleep->setText(QApplication::translate("MainWindow", "Total:", Q_NULLPTR));
        zombie->setText(QApplication::translate("MainWindow", "Total:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
